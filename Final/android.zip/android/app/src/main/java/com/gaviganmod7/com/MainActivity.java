package com.gaviganmod7.com;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
